package games.kingdoms.kingdoms;

import games.kingdoms.kingdoms.admin.staffvault.StaffVault;
import games.kingdoms.kingdoms.admin.vanish.commands.VanishCMD;
import games.kingdoms.kingdoms.admin.vanish.events.JoinEvent;
import games.kingdoms.kingdoms.publiccmds.kingdoms.main.KingdomsCommands;
import games.kingdoms.kingdoms.publiccmds.nightvision.Commands;
import games.kingdoms.kingdoms.publiccmds.randomtp.TeleportUtils;
import games.kingdoms.kingdoms.publiccmds.randomtp.rtp;
import games.kingdoms.kingdoms.publiccmds.teleports.WarzoneCMD;
import games.kingdoms.kingdoms.rankedcmds.feed.feed;
import games.kingdoms.kingdoms.rankedcmds.fly.fly;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Statistic;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerCommandSendEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.permissions.PermissionAttachment;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;

public final class Kingdoms extends JavaPlugin implements Listener {

    public HashMap<String, PermissionAttachment> attachments = new HashMap<>();

    private KingdomsCommands cmd;

    private static Kingdoms plugin;

    public ArrayList<Player> invisiblePlayers = new ArrayList<>();

    @Override
    public void onEnable() {

        //Kingdoms
        plugin = this;
        getCommand("kingdom").setExecutor(new KingdomsCommands());

        //Commands
        nightVision();
        staffVault();
        Feed();
        Fly();
        warZone();
        Rtp();
        Vanish();


        //Scoreboard
        nonPvpBoard();

        //Events
        onJoin_Vanish();

        System.out.print(ChatColor.GREEN + "Kingdoms successfully enabled");

    }

    @Override
    public void onDisable() {
        System.out.print(ChatColor.RED + "Kingdoms successfully disabled");
    }

    //Scoreboard
    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        nonPvPBoard(event.getPlayer());
    }

    @EventHandler
    public void onCommand(PlayerCommandSendEvent event) {
        nonPvPBoard(event.getPlayer());
    }
    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        nonPvPBoard(event.getEntity());
    }

    public void onLeave(PlayerQuitEvent event) {
        nonPvPBoard(event.getPlayer());
    }

    private void nonPvPBoard(Player player) {

        ScoreboardManager manager = Bukkit.getScoreboardManager();
        Scoreboard board = Objects.requireNonNull(manager).getNewScoreboard();
        Objective obj = board.registerNewObjective("NonPvP", "dummy",
                ChatColor.translateAlternateColorCodes('&', "&e&lKingdoms"));
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);
        Score divider = obj.getScore("-----------------------");
        divider.setScore(13);
        Score p = obj.getScore(ChatColor.BLUE.toString() + ChatColor.BOLD + "PLAYER");
        p.setScore(12);
        //edit this to display the user's actual rank
        Score rank = obj.getScore("Rank " + "[" + ChatColor.GOLD + "DEFAULT" + ChatColor.WHITE + "]");
        rank.setScore(11);
        //edit this to show the user's coins
        Score coins = obj.getScore("Coins " + ChatColor.GOLD + "WIP");
        coins.setScore(10);
        Score kills = obj.getScore("Kills " + ChatColor.YELLOW + player.getStatistic(Statistic.PLAYER_KILLS));
        kills.setScore(9);
        Score deaths = obj.getScore(ChatColor.WHITE + "Deaths " + ChatColor.YELLOW + player.getStatistic(Statistic.DEATHS));
        deaths.setScore(8);
        //edit this to show how many challenges have been completed
        Score challenges = obj.getScore(ChatColor.WHITE + "Challenges " + ChatColor.YELLOW + "WIP");
        challenges.setScore(7);
        Score blank = obj.getScore(" ");
        blank.setScore(6);
        Score server = obj.getScore(ChatColor.YELLOW.toString() + ChatColor.BOLD + "SERVER");
        server.setScore(5);
        Score online = obj.getScore("Online " + ChatColor.YELLOW + Bukkit.getOnlinePlayers().size());
        online.setScore(4);
        //edit this to show online Staff
        Score online_staff = obj.getScore("Staff " + ChatColor.YELLOW + "WIP");
        online_staff.setScore(3);
        Score PvP_setting = obj.getScore(ChatColor.DARK_RED + "PvP " + ChatColor.GRAY + "[" + ChatColor.RED + "OFF" + ChatColor.GRAY + "]");
        PvP_setting.setScore(2);
        Score Separator = obj.getScore(ChatColor.WHITE + "-----------------------");
        Separator.setScore(1);
        Score server_ip = obj.getScore(ChatColor.GREEN + "play.kingdoms.games");
        server_ip.setScore(0);
        player.setScoreboard(board);
    }

    private void nightVision() {
        getCommand("nv").setExecutor(new Commands(this));
    }

    private void staffVault() {
        getCommand("staffvault").setExecutor(new StaffVault());
    }

    private void Feed() {
        getCommand("feed").setExecutor(new feed());
    }

    private void Fly() {
        getCommand("fly").setExecutor(new fly(this));
    }

    private void warZone() {
        getCommand("warzone").setExecutor(new WarzoneCMD());
    }

    private void Vanish() {
        getCommand("vanish").setExecutor(new VanishCMD(this));
    }

    private void Rtp() {
        getCommand("rtp").setExecutor(new rtp());
        TeleportUtils utils = new TeleportUtils(this);

        getConfig().options().copyDefaults();
        saveDefaultConfig();
    }

    private void chatStuff() {
        Bukkit.getPluginManager().registerEvents(this, this);
    }
    private void onJoin_Vanish() {
        getServer().getPluginManager().registerEvents(new JoinEvent(this), this);
    }


    public void nonPvpBoard() {
        this.getServer().getPluginManager().registerEvents(this, this);

        if (!Bukkit.getOnlinePlayers().isEmpty()) {
            for (Player online : Bukkit.getOnlinePlayers()) {
                nonPvPBoard(online);
            }
        }
    }

    public static Kingdoms getPlugin() {
        return plugin;
    }
}