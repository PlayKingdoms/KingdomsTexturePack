package games.kingdoms.kingdoms.publiccmds.kingdoms.events;

import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class KingdomSetRankEvent extends Event {

    String rank;
    Player playerWhosRankIsBeingSet;
    CommandSender playerSettingRank;

    private static final HandlerList handlers = new HandlerList();

    public @NotNull HandlerList getHandlers() {
        return handlers;
    }

    public static HandlerList getHandlerList() {
        return handlers;
    }

}
