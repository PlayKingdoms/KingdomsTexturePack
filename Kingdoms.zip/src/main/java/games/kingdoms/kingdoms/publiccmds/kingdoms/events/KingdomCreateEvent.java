package games.kingdoms.kingdoms.publiccmds.kingdoms.events;

import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class KingdomCreateEvent extends Event {
    private static final HandlerList handlers = new HandlerList();

    public boolean isInKingdom() {
        return isInKingdom;
    }

    public void setInKingdom(boolean inKingdom) {
        isInKingdom = inKingdom;
    }

    private boolean isInKingdom;
    private String kingdomName;
    private String owner;
    private String admins;

    private String members;

    public String getKingdomName() {
        return kingdomName;
    }

    public void setKingdomName(String kingdomName) {
        this.kingdomName = kingdomName;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getAdmins() {
        return admins;
    }

    public void setAdmins(String admins) {
        this.admins = admins;
    }

    public String getMembers() {
        return members;
    }

    public void setMembers(String members) {
        this.members = members;
    }

    public KingdomCreateEvent(String kingdomName, String owner, String admins, String members, boolean isInKingdom) {
        this.kingdomName = kingdomName;
        this.owner = owner;
        this.admins = admins;
        this.members = members;
        this.isInKingdom = isInKingdom;
    }

    public @NotNull HandlerList getHandlers() {
        return handlers;
    }

    public static HandlerList getHandlerList() {
        return handlers;
    }
}
