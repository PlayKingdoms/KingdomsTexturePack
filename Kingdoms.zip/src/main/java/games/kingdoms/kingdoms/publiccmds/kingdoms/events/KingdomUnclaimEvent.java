package games.kingdoms.kingdoms.publiccmds.kingdoms.events;

import org.bukkit.Chunk;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class KingdomUnclaimEvent extends Event {
    private static final HandlerList handlers = new HandlerList();

    Chunk chunk;
    Player player;

    public @NotNull HandlerList getHandlers() {
        return handlers;
    }

    public static HandlerList getHandlerList() {
        return handlers;
    }
}
