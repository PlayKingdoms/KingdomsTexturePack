package games.kingdoms.kingdoms.publiccmds.kingdoms.main;

import games.kingdoms.kingdoms.publiccmds.kingdoms.events.KingdomCreateEvent;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.jetbrains.annotations.NotNull;

public class KingdomsCommands implements CommandExecutor, Listener {

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("You must be a player to execute commands");
        } else {

            switch (args.length) {
                case 0:
                    player.sendMessage(ChatColor.RED + "—————— " + ChatColor.YELLOW + "SUGGESTED COMMANDS " + ChatColor.RED + "——————");
                    player.sendMessage(ChatColor.YELLOW + "/kingdom create <kingdom>");
                    player.sendMessage(ChatColor.YELLOW + "/kingdom rename <name>");
                    player.sendMessage(ChatColor.YELLOW + "/kingdom transfer <player>");
                    player.sendMessage(ChatColor.YELLOW + "/kingdom disband");
                    player.sendMessage(ChatColor.YELLOW + "/kingdom invite <player>");
                    player.sendMessage(ChatColor.YELLOW + "/kingdom uninvite <player>");
                    player.sendMessage(ChatColor.YELLOW + "/kingdom join <kingdom>");
                    player.sendMessage(ChatColor.YELLOW + "/kingdom spawn");
                    player.sendMessage(ChatColor.YELLOW + "/kingdom setspawn");
                    player.sendMessage(ChatColor.YELLOW + "/kingdom leave");
                    player.sendMessage(ChatColor.YELLOW + "/kingdom kick <player>");
                    player.sendMessage(ChatColor.YELLOW + "/kingdom map");
                    player.sendMessage(ChatColor.YELLOW + "/kingdom claim");
                    player.sendMessage(ChatColor.YELLOW + "/kingdom unclaim");
                    player.sendMessage(ChatColor.YELLOW + "/kingdom promote <player>");
                    player.sendMessage(ChatColor.YELLOW + "/kingdom demote <player>");
                    player.sendMessage(ChatColor.YELLOW + "/kingdom rank [command] [args]");
                    player.sendMessage(ChatColor.YELLOW + "/kingdom raid [start:end:logs]");
                    player.sendMessage(ChatColor.YELLOW + "/kingdom set <attribute> [args]");
                    player.sendMessage(ChatColor.YELLOW + "/kingdom info <kingdom>");
                    player.sendMessage(ChatColor.YELLOW + "/kingdom walls <show:hide:upgrade>");
                    player.sendMessage(ChatColor.YELLOW + "/kingdom list [page]");
                    break;

                case 1:

                    break;

                case 2:
                    String kingdom = args[1];

                    KingdomCreateEvent e = new KingdomCreateEvent(kingdom, player.getDisplayName(), player.getDisplayName(), player.getDisplayName(), true);

                    //Kingdom does not exist and player is not in a kingdom
                    if (args[0].equalsIgnoreCase("create") && !e.isInKingdom() && !e.getKingdomName().equalsIgnoreCase(args[1])) {
                        e.setKingdomName(kingdom);
                        e.setOwner(player.getDisplayName());
                        e.setAdmins(player.getDisplayName());
                        e.setMembers(player.getDisplayName());
                        e.setInKingdom(true);

                        //Kingdom exists
                    } else if (e.getKingdomName().equalsIgnoreCase(args[1])) {
                        player.sendMessage(ChatColor.WHITE.toString() + ChatColor.BOLD + kingdom + ChatColor.RED + ChatColor.BOLD + " already exists");
                    }

                    break;

            }
        }
        return true;
    }

}