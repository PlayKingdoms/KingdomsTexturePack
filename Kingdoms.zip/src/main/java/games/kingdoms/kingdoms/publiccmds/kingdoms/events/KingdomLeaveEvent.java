package games.kingdoms.kingdoms.publiccmds.kingdoms.events;

import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class KingdomLeaveEvent extends Event {
    private static final HandlerList handlers = new HandlerList();

    String kingdom;
    String leavingPlayer;

    public @NotNull HandlerList getHandlers() {
        return handlers;
    }

    public static HandlerList getHandlerList() {
        return handlers;
    }
}
