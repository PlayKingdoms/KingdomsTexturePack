package games.kingdoms.kingdoms.publiccmds.kingdoms.events;

import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class KingdomDisbandEvent extends Event {
    private static final HandlerList handlers = new HandlerList();

    String kingdom;
    Player owner;
    Player admins;
    Player members;

    public @NotNull HandlerList getHandlers() {
        return handlers;
    }

    public static HandlerList getHandlerList() {
        return handlers;
    }
}
