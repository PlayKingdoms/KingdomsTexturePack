package games.kingdoms.kingdoms.publiccmds.chats;

import org.bukkit.event.Listener;

public class ChatCMD implements Listener {


}
